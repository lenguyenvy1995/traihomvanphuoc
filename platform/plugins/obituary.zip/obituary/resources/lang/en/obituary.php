<?php

return [
    'menu_name' => 'Obituary',
];