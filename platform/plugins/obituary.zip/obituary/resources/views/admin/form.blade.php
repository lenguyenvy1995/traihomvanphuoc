@extends(BaseHelper::getAdminMasterLayoutTemplate())
@section('content')
    <div class="card">
        <div class="card-body">
            {!! $form !!}
        </div>
    </div>
@endsection
