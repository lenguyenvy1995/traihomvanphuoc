<?php

return [
    [
        'name' => 'Floating Buttons',
        'flag' => 'fob-floating-buttons.settings',
    ],
];
